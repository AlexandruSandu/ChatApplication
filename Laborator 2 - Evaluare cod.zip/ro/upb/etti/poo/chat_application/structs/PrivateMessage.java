package ro.upb.etti.poo.chat_application.structs;

public class PrivateMessage extends Message
{
private final String mRecipient;

public PrivateMessage(String recipient, String sender, String content)
{
    super(sender, content);
    this.mRecipient = recipient;
}

public String getRecipient()
{
    return mRecipient;
}

@Override

public String toString()
{
    return "(priv)" + super.toString();
}
}