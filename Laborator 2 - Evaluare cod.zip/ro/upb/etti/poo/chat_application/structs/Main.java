package ro.upb.etti.poo.chat_application.structs;

public class Main {

    public static void main(String[] args) {
        Message m1 = new Message("Ion", "Am plecat la coasa.");
        Message m2 = new Message("Vasile", "Eu raman sa dorm.");
        Message m3 = new Message("Ion", "Da, e o idee mai buna.");

        System.out.println(m1.toString());
        System.out.println(m2.toString());
        System.out.println(m3.toString());
        
        PrivateMessage p1 = new PrivateMessage("Ionut", "Maine mergi la meci?","Andrei");
        PrivateMessage p2 = new PrivateMessage("Viorel", "Ma duc sa imi cumpar o gaina", "Andrei");
        PrivateMessage p3 = new PrivateMessage("Andrei", "Alo da?", "Viorel");
        
        System.out.println(p1.toString());
        System.out.println(p2.toString());
        System.out.println(p3.toString());
    }
}
