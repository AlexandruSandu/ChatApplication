
package ro.upb.etti.poo.chat_application.structs;

public class Message {

    
    
    private String mSender;
    private String content;

   
    public Message(String sender, String content) {
        this.mSender = sender;
        this.content = content;
    }

   
    @Override
    public String toString() {
        return mSender + ":"  + content;
    }
}

