package ro.upb.etti.poo.chat_application.server.config;
import java.io.FileNotFoundException;
import java.io.*;
import java.util.*;

final public class ServerConfig 
   {
       public ServerConfig(String filename) throws FileNotFoundException {
           FileInputStream g = new FileInputStream(filename);
           Scanner scan = new Scanner(g);
           String line;
           while(scan.hasNext())
           {
               
               line = scan.nextLine();
               line = line.trim();
               if(line.startsWith("#") || line.isEmpty()) {
                   continue;
               }
               
               System.out.println(line);
           }
           
           
       }
       
   }

